针对实验3下程序说明:

1. 正常运行方式:
    python test1.py
    python test2.py

2. 单测运行:
    python -m unittest test1.py
    python -m unittest test2.py

另: test2的实现可能比较粗陋