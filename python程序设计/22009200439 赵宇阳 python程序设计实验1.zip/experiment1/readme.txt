针对这几个程序的说明：

test3.py test4.py test5.py 需要有输入数据

其中：
    test3.py读入年份
    test4.py读入x
    test5.py 则比较复杂，最少需要输入文件名，而编码格式可选(可以使用 -h 查看帮助)



运行示例：

python test3.py 2018
python test4.py 1
python test5.py test5.txt